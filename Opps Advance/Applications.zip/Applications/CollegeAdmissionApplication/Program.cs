﻿
using System;
namespace CollegeAdmissionApplication;
    class program
    {
        public static void Main(string[] args)
        {
            /*Files.Create();
            Files.ReadFile();
            
            Operations.StudentData();
            Operations.AdmissionData();
            Operations.DepartmentData();
            Operations.Mainmenu();
            Files.WriteToFiles();*/
            Operations.StartEvent();
           
        }
            
    }

    
