using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ECommerce
{
    public class Operation
    {
        
    public static List<CustomerDetails> customerList = new List<CustomerDetails>();
    public static List<ProductDetails> productList = new List<ProductDetails>();
    public static List<OrderDetails> orderList = new List<OrderDetails>();
     public static CustomerDetails currentCustomer = null;

    }
    
}