﻿using System;
namespace Exercise4
{
    class  Program4
    {
       public static void Main(string[] args)
       {
        Console.Write("Enter the money i :");
        double money = double.Parse(Console.ReadLine());
        double USD = money*0.0122;
        double EUR = money*0.0127;
        double CNY =money*0.0879;
        Console.WriteLine("USD :"+USD);
        Console.WriteLine("EUR :"+EUR);
        Console.WriteLine("CNY :"+CNY);

       } 
    }
}
