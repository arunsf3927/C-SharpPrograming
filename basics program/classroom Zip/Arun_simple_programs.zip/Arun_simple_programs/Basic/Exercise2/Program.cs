﻿using System;
namespace Exercise2
{
    class Program2
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the number in radius");
            double radius=double.Parse(Console.ReadLine());
            double perimeter=  2*3.14*radius;
            double Area=3.14*((radius)*(radius));
            Console.WriteLine("Area :"+Area);
            Console.WriteLine("Perimeter :"+perimeter);
        }
    }
}