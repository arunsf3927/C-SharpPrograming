﻿using System;
    namespace Exercise1
    {
        class Program1
        {
            public static void Main(string[] args)
            {
                 double inch=2.54;
                Console.WriteLine("Enter the number");
                int number=int.Parse(Console.ReadLine());
                double  centimeters=number*inch;
                Console.WriteLine(centimeters);
            }
        }
    }

