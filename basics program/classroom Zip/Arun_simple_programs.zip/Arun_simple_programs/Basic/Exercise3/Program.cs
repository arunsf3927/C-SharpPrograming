﻿using System;
namespace Exercise3
{
    class Program3
    {
        public static void Main(string[] args)
        {
            double a=9/5;
            Console.WriteLine("Enter the degrees on celcius :");
            double Celcius=double.Parse(Console.ReadLine());
            double Fharenheit=Celcius*a+32;
            Console.WriteLine("Degree on Fharenheit is :" +Fharenheit);
        }
    }
}