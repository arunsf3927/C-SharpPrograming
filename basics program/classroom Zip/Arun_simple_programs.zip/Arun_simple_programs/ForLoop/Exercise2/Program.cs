﻿using System;
namespace Exercise1
{
    class Program
    {
    public static void Main(string[] args)
    {
        int sum =0;
        for(int i=1;i<=99;i++)
        {
           sum= sum+i;
           Console.WriteLine("Sum is :"+sum);
        }

    }
    }
}
