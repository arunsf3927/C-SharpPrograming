﻿using System;
namespace Exercise1
{
    class Program
    {
    public static void Main(string[] args)
    {
        int n=2;
        Console.WriteLine("Enter X");
        int X =int.Parse(Console.ReadLine());
         Console.WriteLine("Enter y");
        int Y=int.Parse(Console.ReadLine());
        int v= Y;
        while(n>1)
        {
            Console.WriteLine("Anser is :"+(X*(Y*v));
            n=0;
        }

    }
    }
}