﻿using System;
namespace Exercise5
{
    class Program5
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter a character");
            char character=Char.Parse(Console.ReadLine());
            if(character=='a'||character=='e'||character=='i'||character=='i'||character=='o'||character=='u'||character=='A'||character=='E'||character=='I'||character=='O'||character=='U')
            {
                Console.WriteLine("Its a vowel");
            }
            else{
                Console.WriteLine("Its not a vowel");
            }
        }
    }
}