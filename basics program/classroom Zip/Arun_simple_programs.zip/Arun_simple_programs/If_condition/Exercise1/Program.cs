﻿using System;
namespace Exercise1
{
    class Program1
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the password");
            object password=Console.ReadLine();
            object Corrtect="s3cr3t!P@ssw0rd";
            if(password== Corrtect)
            {
                Console.WriteLine("Welcome :");
            }
            else
            {
                Console.WriteLine("Wrong password :");
            }
        }
    }
}
