﻿using System;
namespace  Exercise2
{
    class Program2
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter input as integer");
            int Integer = int.Parse(Console.ReadLine());
            if(Integer<100)
            {
                Console.WriteLine("Less than 100");
            }
            else if (Integer>=100&&Integer<=200)
            {
                Console.WriteLine("Between 100 and 200") ;   
            }
            else
            {
                Console.WriteLine("Greater than 200");
            }
        }
    }
}
