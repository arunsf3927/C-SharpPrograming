﻿using System;
namespace Exercise4
{
    class program4
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the month You want to calculate Salary");
            string month=(Console.ReadLine());
            Console.WriteLine("Enter the no of leaves");
            int leave =int.Parse(Console.ReadLine());
            if(month== "january")
            {
          Console.WriteLine((31- leave)*500);
            }
             else if(month== "Febrauary")
            {
          Console.WriteLine((28- leave)*500);
            }
              else if(month== "march")
            {
          Console.WriteLine((31- leave)*500);
            }
             else if(month== "april")
            {
          Console.WriteLine((30- leave)*500);
            }
              else if(month== "may")
            {
          Console.WriteLine((31- leave)*500);
            }
             else if(month== "june")
            {
          Console.WriteLine((30- leave)*500);
            }
              else if(month== "july")
            {
          Console.WriteLine((31- leave)*500);
            }
             if(month== "augest")
            {
          Console.WriteLine((30- leave)*500);
            }
              else if(month== "september")
            {
          Console.WriteLine((31- leave)*500);
            }
             else if(month== "october")
            {
          Console.WriteLine((30- leave)*500);
            }
              else if(month== "november")
            {
          Console.WriteLine((31- leave)*500);
            }
        else
            {
          Console.WriteLine((30- leave)*500);
            }
        }
    }
}