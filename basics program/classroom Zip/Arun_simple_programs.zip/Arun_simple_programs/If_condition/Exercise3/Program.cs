﻿using System;
namespace Exercise3
{
    class Program3
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("enter the input speed");
            double speed = double.Parse(Console.ReadLine());
            if(speed<10)
            {
                Console.WriteLine("Slow :");
            }
            else if(speed >=10&&speed<50)
            {
                Console.WriteLine("Average");
            }
            else if(speed>=50&&speed<150)
            {
                Console.WriteLine("fast");
            }
            else if(speed>=150&&speed<1000)
            {
                Console.WriteLine("Ultra fast");
            }
            else
            {
                Console.WriteLine("Extermely fast");
            }
        }
    }
}