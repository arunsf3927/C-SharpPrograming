﻿using System;
namespace Forloop
{
    class program
    {
     public static void Main(string[] args) 
     {
        int i;
        for ( i=0;i<25;i++)
        {
            if(i%2==0)
            {
            Console.WriteLine(" sum of the square of the numbers is:"+i);
            }

        }
        Console.WriteLine("initial value:");
        int initial = int.Parse( Console.ReadLine());
        Console.WriteLine("final value:");
        int final = int.Parse( Console.ReadLine());
        int sum =0;
        for (i=initial;i<=final;i++)
        {
            sum= sum +(i*i);
        }
         Console.WriteLine(sum);
     }
    }
}
