﻿using System;
namespace Exerciser7
{
    class Program
    {
        public static void Main(string[] args)
        {
            int sum=0;
            Console.WriteLine("Enter the starting number");
            int n1=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Difference");
            int d=int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the number of elements");
            int e=int.Parse(Console.ReadLine());
            for(int i=(n1);i<=24;i++)
            {
                //Output Series
                sum =i;
                i=((d-1)+i);
                Console.WriteLine(sum);
                
            }

        }
    }
}