﻿using System;
namespace Exercise8
{
    class program
    {
        public static void Main(string[] args)
        
        {
            int a=2;
            Console.WriteLine("ENTER THE INPUT");
            int n=int.Parse(Console.ReadLine());
    
        while(a>1)
        {
            if(n%2==0)
            {
                Console.WriteLine("even number");
            }
            else
            {
                Console.WriteLine("Odd");
            }
        }
            
        }
    }
}