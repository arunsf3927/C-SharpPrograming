﻿using System;
namespace Exrercise3;

    class Program3
    {
        public static void Main(string[] args)
        {
           int  sum =0;
            Console.WriteLine("enter the Number");
            int n = int.Parse(Console.ReadLine());
            int Temp =n;
            while(n>0)
            {
               int  r=n%10;
               sum =(sum*10)+r;
               n=n/10;
            }
             if(Temp==sum)
             {
                Console.WriteLine("Its a Palinderome");
             }
             else
             {
                Console.WriteLine("Its not a palindrome");
             }

            }
        }
    
