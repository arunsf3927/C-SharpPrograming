﻿using System;
namespace Exercise2
{
    class program
    {
        public static void Main(string[] args)
        {
            int a=0; int b=1;
            Console.WriteLine("Enter the numbrr of terms to display");
            int n=int.Parse(Console.ReadLine());
            int i =0;
            Console.WriteLine("0");
            Console.WriteLine("1");
            while(i<=n)
            {
                int c=a+b;
                Console.WriteLine(c);
                a=b;
                b=c;
                i++;
                
            }
        }
    }
}