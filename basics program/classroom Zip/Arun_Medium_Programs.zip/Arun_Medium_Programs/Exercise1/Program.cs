﻿using System;
namespace Exercise1
{
    class program
    {
        public static void Main(string[] args)
        {
            double n=0;
            Console.WriteLine("Enter the Basic salaray");
            int Basic=int.Parse(Console.ReadLine());
            if(Basic<=1000)
            {
             double HRA=0.20;
                double DA =0.80;
               n=((Basic/HRA)*(Basic/DA));
               Console.WriteLine("annual Gross salary is :"+(n-70));
            }
              else if(Basic<2000)
            {
             double HRA=0.25;
                double DA =0.90;
               n=((Basic/HRA)*(Basic/DA));
               Console.WriteLine( "annual Gross salary is :"+(n-70));
            } else if(Basic>2000)
            {
             double HRA=0.25;
                double DA =0.95;
               n=((Basic/HRA)*(Basic/DA));
               Console.WriteLine("annual Gross salary is :"+(n-7));
            }
        }
        
    }
}
