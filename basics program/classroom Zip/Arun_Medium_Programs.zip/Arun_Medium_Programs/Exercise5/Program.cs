﻿using System;
namespace Exercise5
{
    class Program5
    {
        public static void Main(string[] args)
        {
            int sum=0;
            Console.WriteLine("enter the value of N");
            int n =int.Parse(Console.ReadLine());
            Console.WriteLine("LeapStyleUriParser year of 1 to"+n);
            for(int i=0;i<=n;i++)
            {
                 sum = i;
                 Console.WriteLine(sum);
                i= 3+i++;
            }
        }
    }
}