﻿using System;
namespace LibrarayApplication;
class program
{
    public static void Main(string[] args)
    {
        Operation.MainMenu();
        Operation.UserRegistration();
       Operation.BookDetails();
    
    }
} 
