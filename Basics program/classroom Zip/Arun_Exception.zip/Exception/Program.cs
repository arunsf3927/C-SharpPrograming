﻿using System;
namespace Exception
{
  class Program
  {
    public static void Main(string[] args)
    {
        
        try
        {
            System.Console.WriteLine("Enter number 1");
           int number1=int.Parse(Console.ReadLine());
           System.Console.WriteLine("Enter number 2");
           int number2=int.Parse(Console.ReadLine());
            int c=number1/number2;
        }
        catch(DivideByZeroException e)
        {
            System.Console.WriteLine("An exception Occured:{0}", e.Message);
            System.Console.WriteLine("An ecception Occured:{0}",e.StackTrace);
        }
        catch(FormatException e)
        {
            System.Console.WriteLine("An ecception Occured{0}",e.Message);
            System.Console.WriteLine("An ecception Occured: {0}",e.StackTrace);
        }
        finally
        {
            System.Console.WriteLine("Completed");
        }
        
    }
  }  
}
