﻿using System;
namespace Exercise4
{
    class Program4
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the word");
            string word = Console.ReadLine();
           if(word!=word.Contain

        }
    }
}

