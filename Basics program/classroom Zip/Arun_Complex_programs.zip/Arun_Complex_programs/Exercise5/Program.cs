﻿using System;

    namespace Exercise5
    {
        class Program5
        {
            public static void Main(string[] args)
            {
                Console.WriteLine("Enter the word");
                string word= (Console.ReadLine());
                string a="";
                for(int i=word.Length-1;i>=0;i--)
                {
                
                  a=a+word[i];
                }  
                if(a==word)
                {
                    Console.WriteLine(" palindrome");
                }
                else
                {
                    Console.WriteLine(" not palindrome");
                }
            }
        }
    }
   
