﻿using System;
namespace  Exercise2
{
    class Program2
    {
        public static void Main(string[] args)
        {
            double a=1*2;
            double b=1*2*3;
            double c=1*2*3*4;
            double d=1*2*3*4*5;
            double e=1*2*3*4*5*6;
            int f=1*2*3*4*5*6*7;
            double g=1*2*3*4*5*6*7*8;
            double Factorial=((1+2+(2^2))/(a+(2^3))/(b+(2^4))/(c+(2^5))/(d+(2^6))/(e+(2^7))/(f+(2^8))/(g));
            Console.WriteLine(Factorial);
        }
    }

}

