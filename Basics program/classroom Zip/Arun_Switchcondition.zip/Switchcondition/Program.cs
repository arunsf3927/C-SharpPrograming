﻿using System;
namespace Switchcondition
{
    class program
    {
     public static void Main(string[] args) 
     {
         Console.WriteLine("number 1:");
        int number1 = int.Parse( Console.ReadLine());
         Console.WriteLine("number 2:");
        int number2 = int.Parse( Console.ReadLine());
         Console.WriteLine("Enter the choice what calculation to peeform:");
         char choice =char.Parse( Console.ReadLine());
         switch(choice)
         {
            case '+':
            {
                float addition=(number1 + number2);
                Console.WriteLine(addition);
                break;
            }
            case'-':
            {
                float subration =(number1 - number2);
                Console.WriteLine(subration);
                break;
            }
            case '*':
            {
            float Multiplication=(number1 + number2);
            Console.WriteLine(Multiplication);
            break;
            }
             case '/':
             {
            float division=(number1 / number2);
            Console.WriteLine(division);
            break;
             }
             case '%':
             {
             float percentage=(number1%number2);
             Console.WriteLine(percentage);
             break;
             }
             default:
             {
                Console.WriteLine("Invalid choice");
                break;
             }
         
         }

         
      
     }
    }
}