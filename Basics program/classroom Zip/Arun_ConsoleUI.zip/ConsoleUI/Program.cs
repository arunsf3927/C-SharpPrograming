﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Please note - THIS IS A BAD APPLICATION - DO NOT REPLICATE WHAT IT DOES
// This application was designed to simulate a poorly-built application that
// you need to support. Do not follow any of these practices. This is for 
// demonstration purposes only. You have been warned.
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            string whatDone="";
            int i;
            double hoursWorked;
            double totalTime;
            List<TimeSheetEntry> entrieslist = new List<TimeSheetEntry>();
            Console.Write("Enter where you work ");
            whatDone = Console.ReadLine();
            Console.Write("How long did you do it for: ");
            hoursWorked = double.Parse(Console.ReadLine());
            TimeSheetEntry entry = new TimeSheetEntry();
            entry.HoursWorked = hoursWorked;
            entry.WorkDone = whatDone;
            entrieslist.Add(entry);
            Console.Write("Do you want to enter more time:");
            string choice =(Console.ReadLine().ToLower());
            while (choice == "yes")
            {
                Console.Write("Enter where you worked: ");
                whatDone = Console.ReadLine();
                Console.Write("How long did you do it for: ");
                TimeSheetEntry entry2 = new TimeSheetEntry();
                hoursWorked = double.Parse(Console.ReadLine());
                entry.HoursWorked = hoursWorked;
                entry.WorkDone = whatDone;
                entrieslist.Add(entry2);
                Console.Write("Do you want to enter more time:");
                choice = Console.ReadLine().ToLower();
            }

            totalTime = 0;
            for (i = 0; i < entrieslist.Count; i++)
            {
                if (entrieslist[i].WorkDone.ToLower().Contains("acme"))
                {
                    totalTime += entrieslist[i].HoursWorked;
                }
            }
            Console.WriteLine("Simulating Sending email to acme");
            Console.WriteLine("Your bill is $" + totalTime * 150 + " for the hours worked.");

            totalTime = 0;
            for (i = 0; i < entrieslist.Count; i++)
            {
                if (entrieslist[i].WorkDone.ToLower().Contains("abc"))
                {
                    totalTime += entrieslist[i].HoursWorked;;
                }
            }
            Console.WriteLine("Simulating Sending email to abc");
            Console.WriteLine("Your bill is $" + totalTime * 125 + " for the hours worked.");
            
            totalTime = 0;
            for (i = 0; i < entrieslist.Count; i++)
            {
                totalTime += entrieslist[i].HoursWorked;
            }
            if (totalTime > 40)
            {
                Console.WriteLine("You will get paid $" + (40*10)+((totalTime-40) * 15) + " for your work.");
            }
            else
            {
                Console.WriteLine("You will get paid $" + (40*10)+((totalTime-40) * 10) + " for your time.");
            }
            Console.WriteLine();
            Console.Write("Press any key to exit application...");
            Console.ReadKey();
        }
    }

    public class TimeSheetEntry
    {
        public string WorkDone;
        public double HoursWorked;
    }
}
